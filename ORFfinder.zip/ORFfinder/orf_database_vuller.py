from mysql.connector import (connection)


def orf_database_vul(orf_data_list):
    conn = connection.MySQLConnection(
        host="hannl-hlo-bioinformatica-mysqlsrv.mysql.database.azure.com",
        user="owe7_pg6@hannl-hlo-bioinformatica-mysqlsrv",
        password="blaat1234",
        db="owe7_pg6")
    query = "INSERT INTO orf (sequence, " \
             "start_position, end_position) " \
             "VALUES (%s, %s, %s)"
    print("printing ")
    insert_gegevens1 = orf_data_list
    cursor = conn.cursor(prepared=True)
    cursor.executemany(query, insert_gegevens1)
    cursor.close()
    conn.commit()
