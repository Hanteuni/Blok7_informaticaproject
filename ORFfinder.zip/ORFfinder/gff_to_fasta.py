# def main():
#     temp_ls = file_loader()
#     file_writer(temp_ls)
#
# def file_loader():
#     path_file = "/home/han/augustus.2.5.5/augustus_output.gff"
#     file = open(path_file,"r")
#     file = file.readlines()
#     temp_ls = []
#     read = False
#     seq = ""
#     counter = 0
#     for line in file:
#         if "[" in line:
#             read = True
#         if "]" in line:
#             read = False
#             seq += line
#             header = ">Protein_sequence_" +str(counter)+"\n"
#             seq = seq.replace("# protein sequence =",header).replace("#","").replace("[","").replace("]","")
#             seq = seq.strip()
#             seq = seq+"\n"+"\n"
#             temp_ls.append(seq)
#             counter +=1
#             seq = ""
#         if read == True:
#             seq += line
#     return temp_ls
#
# def file_writer(temp_ls):
#     fasta_file_path = "/home/han/augustus_fasta_output.txt"
#     file = open(fasta_file_path, "w")
#     for item in temp_ls:
#         file.write(item)
#
# main()
