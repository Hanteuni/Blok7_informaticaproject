from tkinter import filedialog

from Weektaak.ORFfinder.Blast_get import ORF_file_reader,blaster_file
from Weektaak.ORFfinder.Blast_parser import xml_file_reader, data_sorter, data_sorteren, data_insertie
from Weektaak.ORFfinder.ORFfinder import file_reader, fasta_maker
from Weektaak.ORFfinder.orf_database_vuller import orf_database_vul
import os


def main():
    # fname = filedialog.askopenfilename(
    #     initialdir='C:\\', title='Select')
    fname = "/home/han/Test_document"
    seqs, hdr = file_reader(fname)
    orf_data_list = fasta_maker(seqs)
    orf_database_vul(orf_data_list)
    dir_path = os.path.dirname(os.path.realpath(__file__))
    ORFs_fasta = dir_path + "/ORFs.txt"
    orf_seqs, orf_hdr = ORF_file_reader(ORFs_fasta)
    blaster_file(orf_hdr, orf_seqs, count=0)
    lijst_posities, data = xml_file_reader(orf_hdr, orf_seqs)
    data = data_sorter(hdr, lijst_posities, data)
    data_list_blast,  data_list_query = data_sorteren(data)
    data_insertie(data_list_blast,  data_list_query)

main()