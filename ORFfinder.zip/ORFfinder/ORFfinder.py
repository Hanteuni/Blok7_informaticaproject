import re


def file_reader(fname):
    """ This function reads the given (fasta formatted) file line by line. If the line starts with > then it will
    be considered a headerr otherwise it will be considered a DNA sequence. Whenever a new header begins the sequence
    will be put in a list and the header will be placed in an other list. Also the sequence will become empty again.
    :param fname: The (fasta formatted) file that the user gave as input.
    :return:    seqs: A list with all the sequences of the file
                hdr: A list with all the headers of the sequence
    """
    seqs = []
    hdr = []
    forward_seq_1 = ""
    file = open(fname, "r")
    for line in file:
        if line.startswith(">"):
            hdr.append(line)
            if forward_seq_1 != "":
                forward_seq_1 = validate_dna(forward_seq_1, seqs)
                seqs = making_reading_frames(forward_seq_1, seqs)
                forward_seq_1 = ""
        else:
            forward_seq_1 += line
    seqs = making_reading_frames(forward_seq_1, seqs)
    return seqs, hdr


def validate_dna(seq):
    """ This function checks wether every nucleotide of the dna sequence equals to A, T, G or C. If it does it will
    return the sequence else it will give a error message
    :param seq: One sequence of the file from file_reader
    :return: seq: A sequence consisted only of A, T, G or C.
    """
    Nucleotides = ['A', 'T', 'G', 'C']
    fasta_sequence = seq.upper()
    for nuc in fasta_sequence:
        if nuc not in Nucleotides:
            return "This isn't a DNA sequence"
    return seq


def reverse_compliment(seq):
    """ This function makes a validated DNA sequence complentaire to the forward stand.
    :param seq: One sequence of the file from file_reader
    :return: A complentair sequence of seq
    """
    return seq.replace("A", "T").replace("T", "A").replace("G", "C").replace("C", "G")


def making_reading_frames(forward_seq_1, seqs):
    """ This function makes from One sequence of the file five other sequence with different reading frames. This is
    by starting from the 2nd or 3rd letter of the sequence and then making it complementair by using the
    reverse_compliment function.
    :param forward_seq_1: One sequence of the file from file_reader
    :param seqs: A list with all the sequences from the file and all of it's reading frames
    :return: seqs: A list with all the sequences from the file and all of it's reading frames
    """
    seq_length = len(forward_seq_1)
    forward_seq_2 = forward_seq_1[1: seq_length - 1]
    forward_seq_3 = forward_seq_1[2: seq_length - 1]
    reverse_seq_1 = reverse_compliment(forward_seq_1)
    reverse_seq_2 = reverse_compliment(forward_seq_2)
    reverse_seq_3 = reverse_compliment(forward_seq_3)
    seqs.append(forward_seq_1)
    seqs.append(forward_seq_2)
    seqs.append(forward_seq_3)
    seqs.append(reverse_seq_1)
    seqs.append(reverse_seq_2)
    seqs.append(reverse_seq_3)
    return seqs


def fasta_maker(seqs):
    """ This function makes a fasta file from the sequences and headers from the seqs and hdr lists and writes
    it away in a file. Furthermore it makes a list of data of the orf (more in orf_finder and orf_data_sorter) and
    retuens this
    :param seqs: A list with all the sequences of the file
    :return: orf_data_list: A list with information about the orf containing the
    start- and stopposition and the orf sequence
    """
    counter = 1
    orf_data_list = []
    for seqeunce in seqs:
        orf, start, stop = orf_finder(seqeunce)
        if orf != "None":
            orf_data_sorter(orf, start, stop, orf_data_list)
            header = ">ORF_sequence " + str(counter)
            orf_fasta_writer(header, orf, counter)
            counter += 1
    return orf_data_list


def orf_finder(sequence):
    """ This function finds a orf witing the given sequence and it's start and stop location. The ORF starts with ATG
    and ends with either TAA, TGA or TAG.
    :param sequence: A sequence from the seqs list that might contain a orf
    :return: orf: The sequence of the orf
            start: The location where the ATG was located for the orf
            Stop: The location where theTAA, TGA or TAG was located for the orf
    """
    reg_ex = "(ATG){1}.*?(TAA|TAG|TGA){1}"
    orf = re.search(reg_ex, sequence)
    orf = str(orf)
    try:
        throwaway, match = orf.split("match")
        start, stop = match_data_parser(throwaway)
    except ValueError:
        orf = "None"
        start = ""
        stop = ""
        return orf, start, stop
    match = str(match).replace("'", "").replace(">", "").replace("=", "")
    orf = match
    return orf, start, stop


def match_data_parser(throwaway):
    """ This gets the location of the start and stop positions of where the orf was located.
    :param throwaway: the part of the match output.
    :return: start: The location where the ATG was located for the orf
            Stop: The location where theTAA, TGA or TAG was located for the orf
    """
    throwaway, location = str(throwaway).split("span=(")
    location = str(location)
    location2 = location.replace(")", "")
    start, stop = location2.split(",",1)
    stop = str(stop).replace(",","").strip()
    return start, stop


def orf_data_sorter(orf, start, stop, orf_data_list):
    """ This function makes the data for the orf ready to be used for to put in the database.
    :param orf: the sequence of the orf
    :param start: The location where the ATG was located for the orf
    :param Stop: The location where theTAA, TGA or TAG was located for the orf
    :param orf_data_list: A list formatted to put into the database
    :return: an updated orf_data_list
    """
    templist = [orf, start, stop]
    orf_data_list.append(templist)


def orf_fasta_writer(header, orf, counter):
    """ Writes the information from the seqs list and hdr list into a fasta formatted file
    :param header: a string >ORF_sequence <number of sequence>
    :param orf: the orf sequence
    :param counter: tbe numver of the orf sequence
    :return: a fasta formatted file witb the orf sequences
    """
    if counter == 1:
        output = open("ORFs.txt", 'w')
        output.writelines(header)
        output.writelines("\n")
        output.writelines(orf)
        output.writelines("\n")
        output.close()
    else:
        output = open("ORFs.txt", 'a')
        output.writelines(header)
        output.writelines("\n")
        output.writelines(orf)
        output.writelines("\n")
        output.close()


