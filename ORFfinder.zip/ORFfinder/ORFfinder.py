import re


def file_reader(fname):
    seqs = []
    hdr = []
    forward_seq_1 = ""
    file = open(fname, "r")
    for line in file:
        if line.startswith(">"):
            hdr.append(line)
            if forward_seq_1 != "":
                forward_seq_1 = validate_dna(forward_seq_1, seqs)
                seqs = making_reading_frames(forward_seq_1, seqs)
                forward_seq_1 = ""
        else:
            forward_seq_1 += line
    seqs = making_reading_frames(forward_seq_1, seqs)
    return seqs, hdr


def validate_dna(seq):  # Check if fasta file is a DNA sequence
    Nucleotides = ['A', 'T', 'G', 'C']
    fasta_sequence = seq.upper()
    for nuc in fasta_sequence:
        if nuc not in Nucleotides:
            return "This isn't a DNA sequence"
    return seq


def reverse_compliment(seq):  # calculates complementary
    return seq.replace("A", "T").replace("T", "A").replace("G", "C").replace("C", "G")


def making_reading_frames(forward_seq_1, seqs):
    seq_length = len(forward_seq_1)
    forward_seq_2 = forward_seq_1[1: seq_length - 1]
    forward_seq_3 = forward_seq_1[2: seq_length - 1]
    reverse_seq_1 = reverse_compliment(forward_seq_1)
    reverse_seq_2 = reverse_compliment(forward_seq_2)
    reverse_seq_3 = reverse_compliment(forward_seq_3)
    seqs.append(forward_seq_1)
    seqs.append(forward_seq_2)
    seqs.append(forward_seq_3)
    seqs.append(reverse_seq_1)
    seqs.append(reverse_seq_2)
    seqs.append(reverse_seq_3)
    return seqs


def fasta_maker(seqs):
    counter = 1
    orf_data_list = []
    for seqeunce in seqs:
        orf, start, stop = orf_finder(seqeunce)
        if orf != "None":
            orf_data_sorter(orf, start, stop, orf_data_list)
            header = ">ORF_sequence " + str(counter)
            orf_fasta_writer(header, orf, counter)
            counter += 1
    return orf_data_list


def orf_finder(sequence):
    reg_ex = "(ATG){1}.*?(TAA|TAG|TGA){1}"
    orf = re.search(reg_ex, sequence)
    orf = str(orf)
    try:
        throwaway, match = orf.split("match")
        start, stop = match_data_parser(throwaway)
    except ValueError:
        orf = "None"
        start = ""
        stop = ""
        return orf, start, stop
    match = str(match).replace("'", "").replace(">", "").replace("=", "")
    orf = match
    return orf, start, stop


def match_data_parser(throwaway):
    throwaway, location = str(throwaway).split("span=(")
    location = str(location)
    location2 = location.replace(")", "")
    start, stop = location2.split(",",1)
    stop = str(stop).replace(",","").strip()
    return start, stop


def orf_data_sorter(orf, start, stop, orf_data_list):
        templist = [orf, start, stop]
        orf_data_list.append(templist)



def orf_fasta_writer(header, orf, counter):
    # Writes ORFs to file
    if counter == 1:
        output = open("ORFs.txt", 'w')
        output.writelines(header)
        output.writelines("\n")
        output.writelines(orf)
        output.writelines("\n")
        output.close()
    else:
        output = open("ORFs.txt", 'a')
        output.writelines(header)
        output.writelines("\n")
        output.writelines(orf)
        output.writelines("\n")
        output.close()


