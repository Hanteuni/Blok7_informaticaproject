import tkinter

def main():
    GUI_builder()

def GUI_builder():
    top = tkinter.Tk()
    
    top.mainloop()

main()