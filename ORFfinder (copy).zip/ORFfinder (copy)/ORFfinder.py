import re


def file_reader(fname):
    seqs = []
    hdr = []
    forward_seq_1 = ""
    file = open(fname, "r")
    for line in file:
        if line.startswith(">"):
            hdr.append(line)
            if forward_seq_1 != "":
                forward_seq_1 = validate_dna(forward_seq_1, seqs)
                seqs = making_reading_frames(forward_seq_1,seqs)
                forward_seq_1 = ""
        else:
            forward_seq_1 += line
    seqs = making_reading_frames(forward_seq_1, seqs)
    return seqs, hdr


def validate_dna(seq):  # Check if fasta file is a DNA sequence
    Nucleotides = ['A', 'T', 'G', 'C']
    fasta_sequence = seq.upper()
    for nuc in fasta_sequence:
        if nuc not in Nucleotides:
            return "This isn't a DNA sequence"
    return seq


def reverse_compliment(seq): #calculates complementary
    return seq.replace("A","T").replace("T","A").replace("G","C").replace("C","G")


def making_reading_frames(forward_seq_1,seqs):
    seq_length = len(forward_seq_1)
    forward_seq_2 = forward_seq_1[1: seq_length - 1]
    forward_seq_3 = forward_seq_1[2: seq_length - 1]
    reverse_seq_1 = reverse_compliment(forward_seq_1)
    reverse_seq_2 = reverse_compliment(forward_seq_2)
    reverse_seq_3 = reverse_compliment(forward_seq_3)
    seqs.append(forward_seq_1)
    seqs.append(forward_seq_2)
    seqs.append(forward_seq_3)
    seqs.append(reverse_seq_1)
    seqs.append(reverse_seq_2)
    seqs.append(reverse_seq_3)
    return seqs


def fasta_maker(seqs):
    counter = 1
    for seqeunce in seqs:
        orf = orf_finder(seqeunce)
        header = ">ORF_sequence " + str(counter)
        counter += 1
        print(header)
        # orf_fasta_writer(header, orf)


def orf_finder(sequence):
    reg_ex = "(ATG){1}.*?(TAA|TAG|TGA){1}"
    orf = re.search(reg_ex, sequence)
    print("ORF",orf)
    return orf


def orf_fasta_writer(header, orf):
    # Writes ORFs to file
    output = open("ORFs.txt", 'w')
    output.writelines(header)
    output.writelines(orf)
    output.close()
