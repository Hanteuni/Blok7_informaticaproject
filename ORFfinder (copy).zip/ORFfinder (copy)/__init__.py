from tkinter import filedialog

from Weektaak.ORFfinder.Blast_get import blaster_file
from Weektaak.ORFfinder.Blast_parser import xml_file_reader, data_sorter, data_sorteren, data_insertie
from Weektaak.ORFfinder.ORFfinder import file_reader, fasta_maker


def main():
    # fname = filedialog.askopenfilename(
    #     initialdir='C:\\', title='Select')
    fname = "/home/han/Test_document"
    seqs, hdr = file_reader(fname)
    fasta_maker(seqs)
    # blaster_file(hdr, seqs, count=0)
    # lijst_posities, data = xml_file_reader()
    # data = data_sorter(hdr, lijst_posities, data)
    # data_tuplelist_lineage, data_tuplelist_protein, \
    # data_tuplelist_fragment = data_sorteren(data)
    # data_insertie(data_tuplelist_lineage, data_tuplelist_protein,
    #               data_tuplelist_fragment)


main()
