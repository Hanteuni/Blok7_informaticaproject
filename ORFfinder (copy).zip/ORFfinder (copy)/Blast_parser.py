from Bio.Blast import NCBIXML
from mysql.connector import (connection)
from Bio import SearchIO


def xml_file_reader(hdr, seqs):
    """The xml_file_reader function reads the XML by looping through the hdr
    list. Then the function puts all the data in a list(see data). The
    function also makes a list with the position  of the data
    :param hdr: list with the headers of the Excel file
    :param seqs: list with the sequences of the Excel file
    :return: lijst_posities: list with positions of the data
    data: a list with the data form the XML files
    *note: The XML have to be in the same directory as the py file
    """
    data = []
    lijst_posities = []
    positie = -1
    positie2 = -1
    for header in hdr:
        print(header)
        positie2 += 1
        result_handle = open(header)
        blast_record = NCBIXML.read(result_handle)
        count = 0
        for alignment in blast_record.alignments:
            for hsp in alignment.hsps:
                if count < 100:
                    positie += 1
                    # appends the position to lijst_posities
                    lijst_posities.append(positie)
                    data.append([])
                    count += 1
                    query_coverage = round((hsp.query_end - hsp.query_start)
                                           / hsp.query_end, 3)
                    data[positie].append(hdr[positie2])         #hdr
                    data[positie].append(seqs[positie2])        #seq
                    data[positie].append(hsp.expect)            #E-val
                    data[positie].append(hsp.score)             #score
                    data[positie].append(hsp.query_start)       #startpos
                    data[positie].append(hsp.query_end)         #stoppos
                    data[positie].append(query_coverage)        #Qcov
    return lijst_posities, data


def data_sorter(hdr, lijst_posities, data):
    """ The data_sorter function sorts the data from the XML files. It also
    ''cleans'' the data so it looks better in the database.
    :param hdr: list with the headers of the Excel file
    :param lijst_posities:  list with positions of the data
    :param data: a list with the data form the XML files
    :return: data: tuples of filtered data from the XML files
    """
    teller = -1
    hdr_filtered = []
    for header in hdr:
        query_result = SearchIO.parse(header, 'blast-xml')
        for result in query_result:
            count = 0
            for hit in result:
                # checks every chosen hit
                for hsp in hit:
                    if count < 100:
                        teller += 1

                        data[lijst_posities[teller]].append(
                            hit.description.split('[')[1].strip(']'))
                        data[lijst_posities[teller]].append(
                            hit.description.split('[')[0])
                        data[lijst_posities[teller]].append(hit.accession)
                        count += 1
    for header in hdr:
        blast_qresult = SearchIO.read(header, "blast-xml")
        if len(blast_qresult) != 0:
            hdr_filtered.append(header)
    return data


def data_sorteren(data):
    """ The data_sorteren sorts the data and makes them into tuples to
    insert into the database.
    :param data: tuples of filtered data from the XML files
    :return: data_tuplelist_lineage: Tuplelist of the lineage to insert into
    the database
     data_tuplelist_protein: Tuplelist of the protein to insert into
    the database
     data_tuplelist_fragment: Tuplelist of the fragment to insert into
    the database
    """
    data_tuplelist_lineage = []
    data_list_protein = []
    data_tuplelist_protein = []
    data_tuplelist_fragment = []
    counter = -1
    # for lijst in data:
    #     data_tuplelist_fragment.append(lijst[0:2])                       #header + seq
    #     data_tuplelist_fragment[counter].extend(tuple(lijst[9:10]))      #Accesion code
    # for lijst3 in data:
    #     data_list_protein.append((lijst3[2:3]))                      #E_val
    #     data_list_protein[counter].extend(tuple(lijst3[6:7]))        #Q_coverage
    #     data_list_protein[counter].extend(tuple(lijst3[9:10]))       #Accesion code
    # for lijst3 in data_list_protein:
    #     data_tuplelist_protein.append(tuple(lijst3))                 #e-val,qcov,accession code
    # for lijst4 in data_tuplelist_fragment:
    #     data_tuplelist_fragment.append(tuple(lijst4))

    return data_tuplelist_lineage, data_tuplelist_protein, \
           data_tuplelist_fragment

def data_insertie(data_tuplelist_lineage, data_tuplelist_protein,
                  data_tuplelist_fragment):
    """The data_insertie insert the tuple lists(se parameters) into the
    database using mysql.connector.
    :param data_tuplelist_lineage:  Tuplelist of the lineage to insert into
    the database
    :param data_tuplelist_protein: Tuplelist of the protein to insert into
    the database
    :param data_tuplelist_fragment:  Tuplelist of the fragment to insert into
    the database
    :return: message when the lists are succesfully inserted into the database
    """
    conn = connection.MySQLConnection(
        host="hannl-hlo-bioinformatica-mysqlsrv.mysql.database.azure.com",
        user="owe7_pg6@hannl-hlo-bioinformatica-mysqlsrv",
        password="blaat1234",
        db="owe7_pg6")
    query1 = "INSERT INTO blast (e_value, " \
             "coverage, accession_code) " \
             "VALUES (%s, %s, %s)"
    print("printing ")
    print(data_tuplelist_protein)
    insert_gegevens1 = data_tuplelist_protein
    cursor = conn.cursor(prepared=True)
    # cursor.executemany(query1, insert_gegevens1)
    cursor.close()
    conn.commit()
    # print("---------Data insertion into table query done----------")
    query2 = "INSERT INTO query (header, " \
             "sequence, accession_code) " \
             "VALUES (%s, %s, %s )"
    insert_gegevens2 = data_tuplelist_protein
    cursor = conn.cursor(prepared=True)
    # cursor.executemany(query2, insert_gegevens2)
    cursor.close()
    conn.commit()
    print("Insertion done, closing connection...")
    conn.close()
    print("Connection closed")
